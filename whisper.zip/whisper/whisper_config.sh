# whisper_config.sh

# Replace 'YOUR_API_KEY' with your actual OpenAI Whisper API key
export WHISPER_API_KEY="YOUR_API_KEY"
